import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { AuthenticateService } from '../_services/authenticate.service';

export class User 
{
    userId: number;
    userRole = "user";
    userName: string; 
    userMail: string;
    userPassword: string;
    userContact: number;
    userGender: string;
    userAge: number; 
    secretWord: string;
}

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit 
{

  public userMail: string;
  public secretWord: string;
  user: User;

  loginForm: FormGroup;
  invalidLogin = false;
  submitted: boolean = false;

  constructor(private userService: UserService, private router: Router,
              private authService: AuthenticateService, private formBuilder: FormBuilder) { }


  /*****************************************************************************************
   * Method:        ngOnInit is life cycle hook called by angular at first
   * params:
   * return:
   * Description:   ngOnInit is getting the values of the userMail and secretWord(NickName)
   *                entered by the user and passing the values to the verifyUser(). 
   *****************************************************************************************/            
  ngOnInit(): void 
  {
    this.loginForm  =  this.formBuilder.group({
      userMail: ['', Validators.required],
      secretWord: ['', Validators.required]
  });
  }

  /****************************************************************************************
  * Method:        userLogin
  * params:
  * return:        
  * Description:   This method is getting the userMail andsecretWord(NickName)
  *                from NgOnInIt and sending those values to the server 
  *                end to check whether the details exist or not and 
  *                returning integer type
  *                as 1 -> User's verified correct
  *                as 0-> User's details doesn't match.(triggers inValidLogin div in html.)
  *                Also, it is storing a token of user's detail in localStroage for 
  *                unwanted entering in the update-password page.
  *****************************************************************************************/
  verifyUser()
  {
    this.submitted = true;
    if (this.loginForm.valid) 
    {
      this.authService.login(this.loginForm.value)
      this.userService.userMailPass = this.loginForm.controls.userMail.value;
      this.userMail = this.loginForm.controls.userMail.value;
      this.secretWord = this.loginForm.controls.secretWord.value;
      this.userService
        .getUserVerify(this.userMail, this.secretWord)
        .subscribe((data) => 
        {
          if (data === 1) 
          {
            this.router.navigate(["/updatepassword"]);
          } 
          else 
          {
            this.invalidLogin = true;
          }
        });
    } 
    else 
    {
      return;
    }
  };

}
