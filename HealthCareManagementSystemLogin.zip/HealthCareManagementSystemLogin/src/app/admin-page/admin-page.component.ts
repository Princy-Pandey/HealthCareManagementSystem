import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticateService } from '../_services/authenticate.service';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {

  constructor(private authService: AuthenticateService, private router: Router) { }

  ngOnInit(): void {
  }

  /**********************************************************************
  * Method:        logout
  * params:
  * return:        
  * Description:   This method is used to delete the token created while 
  *                logining in and sending the user to home page.
  ************************************************************************/
  logout()
  {
    this.authService.logout();
    this.router.navigateByUrl('/home');
  }

}
