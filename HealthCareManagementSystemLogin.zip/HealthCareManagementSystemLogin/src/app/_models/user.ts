export class User 
{
    userId: string;
    userRole = "user";
    userName: string; 
    userMail: string;
    userPassword: string;
    confirmPassword: string;
    userContact: number;
    userGender: string;
    userAge: number; 
    secretWord: string;
    loginStatus: string;
}

export class Admin
{
    userId: string;
    userRole = "admin";
    userMail: string;
    userPassword: string;
}
