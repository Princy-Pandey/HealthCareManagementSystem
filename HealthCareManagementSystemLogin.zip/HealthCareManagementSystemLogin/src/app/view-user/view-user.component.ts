import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../_models/user';
import { UserService } from '../_services/user.service';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
  /**************************************************************************
   * creating books array of Book type to store the book detail 
  /**************************************************************************/
  users: User[] = [];
  msg: string;

  constructor(private userService: UserService, private router: Router) { }

  /************************************************************************
   * Method:        ngOnInit is life cycle hook called by angular at first
   * params:
   * return:
   * Description:   ngOnInit is getting the values from the user table and
   *                showing it in the table on the front end. 
   ************************************************************************/
  ngOnInit() {
    this.userService.viewUsers().subscribe(data => this.users = data);
  }


  /************************************************************************
   * Method:        BackToAdmin
   * params:
   * return:        
   * Description:   This method is used to transist from viewuser component
   *                to adminpage component.
   ************************************************************************/
  BackToAdmin() {
    this.router.navigateByUrl('/adminpage');
  }


  /*********************************************************************
   * Method:        deleteDetails
   * params:        user
   * return:        
   * Description:   This method is helping in deleting the selected row
   *                when pressing a button in the table.
   **********************************************************************/
  deleteDetails(user: User): void {
    console.log("Row Deleted!!")
    this.userService.deleteUser(user)
      .subscribe(data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  /*column:string;
  change(col:string)
  {
    console.log(col);
    this.column=col;
  }*/

}
