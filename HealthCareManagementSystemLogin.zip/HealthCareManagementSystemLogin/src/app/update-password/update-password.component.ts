import { Component, OnInit } from '@angular/core';
import { User } from '../_models/user';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { AuthenticateService } from '../_services/authenticate.service';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent implements OnInit {

  /*************************************************************************
  * creating book instance for every time manupulate the data
  *************************************************************************/
  user: User = new User();
  userMail: string;
  errorInfo: string = undefined;
  info: string = undefined;
  updateMail: string;

  constructor(private userService: UserService, private authService: AuthenticateService,
    private router: Router, ) { }

  
  /*******************************************************************************
   * Method:        ngOnInit is life cycle hook called by angular at first
   * params:
   * return:
   * Description:   ngOnInit is getting the updateMail value from the userMailPass
   *                stored in the service class and then finding that mail is 
   *                present in the user or not. if yes returning the user details. 
   *******************************************************************************/  
  ngOnInit(): void {
    this.updateMail = this.userService.userMailPass;
    this.userService.findByMail(this.updateMail).subscribe(data => this.user = data);
  }


  /************************************************************************
   * Method:        updatePassword
   * params:
   * return:        
   * Description:   This method is used updating the password provided by
   *                the user after getting verified.
   ************************************************************************/
  updatePassword() {
    console.log("Row Updated!!")
    this.userService
      .updatePassword(this.user)
      .subscribe(data => {
        this.user = data;
        this.info = data;
        this.errorInfo = undefined;
      },
        error => {
          this.info = undefined;
          this.errorInfo = JSON.stringify(error.error.text);
        });
    this.authService.logout();
    this.router.navigateByUrl("/login")
  }

}
